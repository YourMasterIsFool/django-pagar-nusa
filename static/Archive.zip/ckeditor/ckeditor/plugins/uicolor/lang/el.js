﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","el",{title:"Διεπαφή Επιλογής Χρωμάτων",preview:"Ζωντανή Προεπισκόπηση",config:"Επικολλήστε αυτό το κείμενο στο αρχείο config.js",predefined:"Προκαθορισμένα σύνολα χρωμάτων"});